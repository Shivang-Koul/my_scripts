{\rtf1\ansi\ansicpg1252\cocoartf2822
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;\f1\fnil\fcharset0 HelveticaNeue;}
{\colortbl;\red255\green255\blue255;\red13\green16\blue20;\red255\green255\blue255;}
{\*\expandedcolortbl;;\cssrgb\c5882\c7843\c10196;\cssrgb\c100000\c100000\c100000;}
\paperw11900\paperh16840\margl1440\margr1440\vieww38200\viewh21600\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs60 \cf0 import boto3\
import json\
\
# AWS Configuration\
AWS_REGION = \'93ap-south-1\'94\
RDS_INSTANCE_IDENTIFIER = \'93cloudage\'94\
S3_BUCKET_NAME = \'93cloudage.ae\'94\
EXPORT_TASK_IDENTIFIER = "
\f1\fs28 \cf2 \cb3 \expnd0\expndtw0\kerning0
db-YPYJQDPTCFH6NS6PYKTDML3F2A
\f0\fs60 \cf0 \cb1 \kerning1\expnd0\expndtw0 "\
#IAM_ROLE_ARN = "arn:aws:rds:ap-south-1:706769905020:db:cloudage:role/your-role-name"\
\
# RDS Client\
rds_client = boto3.client('rds', region_name=ap-south-1a)\
\
def export_rds_to_s3():\
    try:\
        response = rds_client.start_export_task(\
            ExportTaskIdentifier=EXPORT_TASK_IDENTIFIER,\
            SourceArn=f"arn:aws:rds:\{AWS_REGION\}:your-account-id:db:\{RDS_INSTANCE_IDENTIFIER\}",\
            S3BucketName=S3_BUCKET_NAME,\
            IamRoleArn=\'93\'94,\
            KmsKeyId=""\
        )\
        print("Export Task Started:")\
        print(json.dumps(response, indent=4))\
    except Exception as e:\
        print(f"Error: \{e\}")\
\
if __name__ == "__main__":\
    export_rds_to_s3()}