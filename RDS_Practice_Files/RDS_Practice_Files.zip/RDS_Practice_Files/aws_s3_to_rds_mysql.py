{\rtf1\ansi\ansicpg1252\cocoartf2822
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\paperw11900\paperh16840\margl1440\margr1440\vieww23380\viewh16760\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs82 \cf0 import boto3\
import pymysql\
\
# AWS Configuration\
AWS_REGION = "us-east-1"\
S3_BUCKET_NAME = "your-s3-bucket-name"\
S3_OBJECT_KEY = "your-object-key.csv"\
IAM_ROLE_ARN = "arn:aws:iam::your-account-id:role/your-role-name"\
\
# RDS MySQL Configuration\
RDS_HOST = "your-rds-hostname"\
RDS_PORT = 3306\
RDS_USER = "your-username"\
RDS_PASSWORD = "your-password"\
RDS_DATABASE = "your-database"\
RDS_TABLE = "your-table"\
\
# Initialize S3 Client\
s3_client = boto3.client('s3', region_name=AWS_REGION)\
\
# Function to download the file from S3\
def download_from_s3(bucket_name, object_key, download_path):\
    try:\
        s3_client.download_file(bucket_name, object_key, download_path)\
        print(f"File downloaded from S3: \{download_path\}")\
    except Exception as e:\
        print(f"Error downloading file from S3: \{e\}")\
\
# Function to insert data into RDS MySQL\
def insert_into_rds(file_path):\
    try:\
        # Establish RDS Connection\
        connection = pymysql.connect(\
            host=RDS_HOST,\
            port=RDS_PORT,\
            user=RDS_USER,\
            password=RDS_PASSWORD,\
            database=RDS_DATABASE\
        )\
        cursor = connection.cursor()\
\
        # Open file and insert into RDS\
        with open(file_path, "r") as file:\
            for line in file:\
                values = line.strip().split(",")\
                query = f"INSERT INTO \{RDS_TABLE\} VALUES (\{','.join(['%s'] * len(values))\})"\
                cursor.execute(query, values)\
        \
        connection.commit()\
        print("Data inserted into RDS MySQL successfully.")\
    except Exception as e:\
        print(f"Error inserting data into RDS MySQL: \{e\}")\
    finally:\
        if cursor:\
            cursor.close()\
        if connection:\
            connection.close()\
\
if __name__ == "__main__":\
    local_file_path = "/tmp/temp_file.csv"\
    download_from_s3(S3_BUCKET_NAME, S3_OBJECT_KEY, local_file_path)\
    insert_into_rds(local_file_path)}