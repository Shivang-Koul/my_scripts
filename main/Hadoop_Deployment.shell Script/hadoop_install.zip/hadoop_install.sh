#!/bin/bash

# Update package list and install essential packages
sudo apt-get update
sudo apt-get install -y wget openjdk-8-jdk ssh

# Generate SSH keys and configure SSH for localhost
ssh-keygen -t rsa -P '' -f ~/.ssh/id_rsa
cat ~/.ssh/id_rsa.pub >> ~/.ssh/authorized_keys
chmod 0600 ~/.ssh/authorized_keys
ssh -o "StrictHostKeyChecking=no" localhost 'echo "SSH connection successful!"'

# Download and install Hadoop 1.2.1
wget https://archive.apache.org/dist/hadoop/common/hadoop-1.2.1/hadoop-1.2.1.tar.gz
tar -xzf hadoop-1.2.1.tar.gz
sudo mv hadoop-1.2.1 /usr/local/hadoop/
sudo chown -R ubuntu:ubuntu /usr/local/hadoop

# Configure environment variables
cat >> ~/.bashrc <<EOL
export HADOOP_PREFIX=/usr/local/hadoop/
export PATH=$PATH:$HADOOP_PREFIX/bin
export JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64
export PATH=$PATH:$JAVA_HOME
EOL

# Reload bash profile
source ~/.bashrc

# Configure Hadoop environment

cat >> /usr/local/hadoop/conf/hadoop-env.sh <<EOL
export JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64
export HADOOP_OPTS=-Djava.net.preferIPv4Stack=true
EOL

# Configure Hadoop core-site.xml
sudo sed -i '/<configuration>/,/<\/configuration>/d' /usr/local/hadoop/conf/core-site.xml
cat >> /usr/local/hadoop/conf/core-site.xml <<EOL
<configuration>
    <property>
        <name>fs.default.name</name>
        <value>hdfs://localhost:9000</value>
    </property>
    <property>
        <name>hadoop.tmp.dir</name>
        <value>/usr/local/hadoop/hdfs/tmp</value>
    </property>
</configuration>
EOL

# Configure Hadoop hdfs-site.xml

sudo sed -i '/<configuration>/,/<\/configuration>/d' /usr/local/hadoop/conf/hdfs-site.xml
cat >> /usr/local/hadoop/conf/hdfs-site.xml <<EOL
<configuration>
    <property>
        <name>dfs.replication</name>
        <value>1</value>
    </property>
</configuration>
EOL

# Configure Hadoop mapred-site.xml
sudo sed -i '/<configuration>/,/<\/configuration>/d' /usr/local/hadoop/conf/mapred-site.xml
cat >> /usr/local/hadoop/conf/mapred-site.xml <<EOL
<configuration>
    <property>
        <name>mapred.job.tracker</name>
        <value>localhost:9001</value>
    </property>
</configuration>
EOL

# Format Hadoop namenode

/usr/local/hadoop/bin/hadoop namenode -format

# Start Hadoop services
/usr/local/hadoop/bin/start-all.sh
